import React from 'react';

function Logo() {
  return (
    <>
      <h1>Logo</h1>
    </>
  );
}

export default Logo;
